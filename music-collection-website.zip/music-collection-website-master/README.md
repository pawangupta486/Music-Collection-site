# music-collection-website
In this repository, I have collected top 10 songs of different feelings. I have used pure HTML in this project.
